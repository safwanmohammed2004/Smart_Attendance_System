import face_recognition
import cv2
import numpy as np
import os
import pandas as pd
from datetime import datetime
import time
import winsound

# Folder with known faces
known_faces_dir = 'images'
tolerance = 0.6

known_face_encodings = []
known_face_names = []

# Load known faces
for filename in os.listdir(known_faces_dir):
    if filename.endswith(('.jpg', '.png', '.jpeg')):
        image_path = os.path.join(known_faces_dir, filename)
        image = face_recognition.load_image_file(image_path)
        encodings = face_recognition.face_encodings(image)
        if encodings:
            known_face_encodings.append(encodings[0])
            known_face_names.append(os.path.splitext(filename)[0])

# Setup webcam
video_capture = cv2.VideoCapture(0)

# Attendance file setup
today = datetime.now().strftime('%d-%m-%Y')
attendance_file = f'attendance_{today}.csv'

# Write header if file doesn't exist
if not os.path.isfile(attendance_file):
    df = pd.DataFrame(columns=['Name', 'Date', 'Time'])
    df.to_csv(attendance_file, index=False)

# Load already marked names to prevent duplicates
existing_df = pd.read_csv(attendance_file)
detected_names = set(existing_df['Name'].values)

print("Running...")

last_detection_time = time.time()

while True:
    ret, frame = video_capture.read()
    if not ret:
        break

    small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
    rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

    face_locations = face_recognition.face_locations(rgb_small_frame)
    face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

    current_names = []

    for face_encoding in face_encodings:
        matches = face_recognition.compare_faces(known_face_encodings, face_encoding, tolerance)
        name = "Unknown"

        face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
        best_match_index = np.argmin(face_distances)

        if matches[best_match_index]:
            name = known_face_names[best_match_index]

        current_names.append(name)

        # Mark attendance only once per day
        if name not in detected_names and name != "Unknown":
            now = datetime.now()
            date_str = now.strftime('%d-%m-%Y')
            time_str = now.strftime('%H:%M:%S')

            new_entry = pd.DataFrame([[name, f'"{date_str}"', time_str]], columns=['Name', 'Date', 'Time'])
            new_entry.to_csv(attendance_file, mode='a', header=False, index=False)

            print(f"{name} marked present at {time_str}")
            winsound.Beep(1000, 300)  # Play beep after marking attendance

            detected_names.add(name)
            last_detection_time = time.time()

    # Draw rectangles and labels
    for (top, right, bottom, left), name in zip(face_locations, current_names):
        top *= 4
        right *= 4
        bottom *= 4
        left *= 4

        cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
        cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 255, 0), cv2.FILLED)

        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(frame, name, (left + 6, bottom - 6), font, 0.8, (0, 0, 0), 2)

    # Show the frame
    cv2.imshow('Attendance System', frame)

    # Exit if no face detected after 4 seconds
    if time.time() - last_detection_time > 4:
        print("No new face detected. Exiting...")
        break

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Cleanup
video_capture.release()
cv2.destroyAllWindows()
